import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../services/login.service';
import { LoginCredentialsModel } from '../model/login-credentials-model';
import { FormControl, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // form controls
  emailControl = new FormControl();
  passwordControl = new FormControl();

  input: LoginCredentialsModel;

  incorrectEmailStatus = false;
  incorrectPasswordStatus = false;
  constructor(private router: Router, private loginService: LoginService) {
    this.input = new LoginCredentialsModel();
    this.input.email = '';
    this.input.password = '';
  }

  ngOnInit() {
  }
  navigateToHome() {
     // navigate to home page on click of Go to Home button
     this.router.navigate(['/home']);
  }
  clear() {
    this.emailControl.clearValidators();
    this.passwordControl.clearValidators();
    this.incorrectEmailStatus = false;
    this.incorrectPasswordStatus = false;

  }
  validate() {
    // validates email
    if (this.input.email !== '') {
      if (this.loginService.correctCredentials.email !== this.input.email) {
        this.incorrectEmailStatus = true;
        this.emailControl.clearValidators();
      }
     } else {
       this.emailControl.setErrors(Validators.required);
     }
     // validates password
   if (this.input.password !== '') {
    if (this.loginService.correctCredentials.password !== this.input.password) {
      this.incorrectPasswordStatus = true;
      this.passwordControl.clearValidators();
    }
   } else {
    this.passwordControl.setErrors(Validators.required);
   }
   // validates for correct credentials
    if (this.loginService.correctCredentials.email === this.input.email &&
      this.loginService.correctCredentials.password === this.input.password) {
        alert('Login successfull!');
        this.router.navigate(['/hello']);
    }
  }
}
