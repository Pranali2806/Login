package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {
	@FindBy(name="graduation")
	WebElement graduation;
	
	@FindBy(name="technologies")
	WebElement technologies;
	
	@FindBy(id="txtPercent")
	WebElement percentage;
	
	@FindBy(id="txtPassingYear")
	WebElement passingYear;
	
	@FindBy(id="txtProjectName")
	WebElement projectName;
	
	@FindBy(id="txtOtherTech")
	WebElement otherTech;
	
	public String getPercentage() {
		return this.percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public String getPassingYear() {
		return this.passingYear.getAttribute("value");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}
	
	public String getProjectName() {
		return this.projectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}
	
	public String getOtherTech() {
		return this.otherTech.getAttribute("value");
	}

	public void setOtherTech(String otherTech) {
		this.otherTech.sendKeys(otherTech);
	}
	
	public void clickGraduation() {
		Select select = new Select(graduation);
		select.selectByVisibleText("BE");
	}
	
	public void clickTechnologies() {
		Select select = new Select(technologies);
		select.selectByVisibleText("Angular");
	}
}
