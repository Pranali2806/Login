package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Personal {
	@FindBy(id="txtFirstName")
	WebElement firstName;
	
	@FindBy(id="txtLastName")
	WebElement lastName;
	
	@FindBy(id="txtEmail")
	WebElement email;
	
	@FindBy(id="txtPhone")
	WebElement phoneNumber;
	
	@FindBy(id="txtAddress1")
	WebElement address1;
	
	@FindBy(id="txtAddress2")
	WebElement address2;
	
	@FindBy(name="city")
	WebElement city;

	@FindBy(name="state")
	WebElement state;
	
	public String getFirstName() {
		return this.firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return this.lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPhoneNumber() {
		return this.phoneNumber.getAttribute("value");
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber.sendKeys(phoneNumber);
	}
	
	public String getAddress1() {
		return this.address1.getAttribute("value");
	}

	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);
	}
	public String getAddress2() {
		return this.address2.getAttribute("value");
	}

	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);
	}
	public void clickCity() {
		Select select = new Select(city);
		select.selectByVisibleText("Pune");
	}
	
	public void clickState() {
		Select select = new Select(state);
		select.selectByVisibleText("Maharashtra");
	}
}

